import './FormCard.css';

export default function FormCard({ children }) {
    return <div className="form-card">{children}</div>;
}